teameyo Updates


V1.01 � 1/27/2019

1) Paypal payment gateway error fixed.
2) Staff and Client trash Images fixed. 
3)Forget Password page reset fixed 
4) Admin, Staff and client profile update issue Fixed. 



